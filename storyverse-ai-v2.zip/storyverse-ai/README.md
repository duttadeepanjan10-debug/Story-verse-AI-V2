# StoryVerse AI — v2

A mobile-first Expo / React Native character chat prototype with character discovery, custom personas, local conversation saving, local memory notes and an AI backend connector.

## Build an APK automatically (no Android Studio needed)

1. Download and extract this ZIP.
2. In GitHub, create a new repository.
3. Upload **all extracted project files and folders** (including `.github/workflows/build-apk.yml`) into the repository.
4. Open the repository's **Actions** tab. Select **Build StoryVerse APK**, choose **Run workflow**.
5. Wait for a successful run. Open the run and download the `StoryVerse-APK` artifact.

The workflow builds a release APK using GitHub-hosted Android build tools. It is not signed for Play Store distribution.

## AI backend

The mobile app intentionally does not embed a provider secret. Run a backend separately:

1. Install Node.js on a computer or hosting service.
2. In `backend/`, run `npm install`.
3. Copy `.env.example` to `.env`, then set `AI_API_KEY` and (optionally) `AI_MODEL` / `AI_API_BASE`.
4. Run `npm start`.
5. Configure the app's Settings screen with the backend URL (for example `http://192.168.1.20:8787` on a shared Wi-Fi network; use a secure HTTPS URL for remote hosting).

Do not expose the backend publicly without appropriate security controls, rate limiting, access restrictions, and provider billing protections. The example backend is a minimal demo, not production-ready.

## Features
- Anime-inspired starter character catalog and search (not exhaustive; character names are fan-fiction prompts, not official content).
- Custom character creation with personality and opening scene.
- AI chat through a separately hosted backend.
- Saved chat transcripts and character memory notes stored locally on the device.
- Memory notes are user-curated from recent dialogue and may need editing; not automatic semantic memory.
- Suitable-for-teen content guardrail in the backend system prompt.

## Limitations
- No account system or cloud sync.
- Saved data remains on the device and is not encrypted by this demo.
- Memory note generation is a simple recent-message recap, not an AI-generated summary.
- Backend must be reachable from the phone. For remote hosting, use HTTPS.
